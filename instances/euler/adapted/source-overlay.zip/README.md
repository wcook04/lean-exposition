# Euler adapted edition source overlay

This patch builds the ordinary adapted edition of *Finite-Time Singularity
Formation for the Three-Dimensional Euler Equations* and its auxiliary
note. Levent Alpöge, Tristan Buckmaster and Matei P. Coiculescu wrote the
original manuscript. Will Cook prepared this adaptation with AI assistance.
The authors' original AI statement remains in the paper.

Apply the patch to the authors' public TeX source. The patch uses the
specific revision below. Build the main paper first to give the auxiliary
note access to its cross-references.

From the extracted archive directory, run

```sh
git clone https://github.com/mcoiculescu/EulerBlowupPublic.git
git -C EulerBlowupPublic checkout --detach fd3a1588967810b9abe42a1dcf46ee662d6434e2
cd EulerBlowupPublic/manuscript/source
patch -p1 < ../../../ordinary-edition.patch
tectonic --keep-intermediates main.tex
(cd anc/auxiliary && tectonic --keep-intermediates terminal_smoothness.tex)
mkdir -p pdf
cp main.pdf pdf/euler-adapted-v3.pdf
cp anc/auxiliary/terminal_smoothness.pdf pdf/euler-adapted-auxiliary-v3.pdf
```

These commands use Tectonic 0.15.0. Keep the two release PDFs together
under their published filenames so the auxiliary note can open its
references in the main paper.
